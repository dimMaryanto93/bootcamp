package com.tabeldata.java.core;

public class Persegi{

	public static void main(String[] args){
		Double sisi = 50d;
		System.out.println("Dengan sisi "+ sisi + " maka luas persegi tersebut adalah " + ((sisi * sisi) / 100) + "m");
	}
}
