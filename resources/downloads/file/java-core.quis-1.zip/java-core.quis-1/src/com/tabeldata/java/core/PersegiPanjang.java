package com.tabeldata.java.core;

public class PersegiPanjang{

	private static Integer panjang, lebar;

	public static void main(String[] args){
		panjang = 10;
		lebar = 5;
		Integer luas = panjang * lebar;
		System.out.println("Panjang "+ panjang + "cm, Lebar "+ lebar + "cm. maka luas persegi panjang adalah " + luas + "cm");	
	}
}
