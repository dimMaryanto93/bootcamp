package com.tabeldata.java.core;

import java.lang.Math;

public class Lingkaran{

	private static final Integer jariJari = 15;

	public static void main(String[] args){
		Integer diameter = jariJari * 2;
		System.out.println(" pi adalah " + Math.PI +" maka keliling lingkaran adalah " + (Math.PI * diameter) );
	}

}
