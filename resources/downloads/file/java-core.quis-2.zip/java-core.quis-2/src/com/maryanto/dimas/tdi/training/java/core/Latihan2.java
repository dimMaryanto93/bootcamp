package com.maryanto.dimas.tdi.training.java.core;

import java.lang.Math;

public class Latihan2{

	public static void main(String[] ags){
		for(int i = 0; i < 5 ; i++){
			for(int j = 0; j < 5; j++){
				if(i == 0 || i == 2){
					System.out.print((i*j) + " ");				
				} else if(i == 1){
					System.out.print(Math.pow(j, j)+" ");				
				} 
			}
			System.out.println();
		}	
	}
}
