package data.list.model;

public class Kelas{

	private String nama;
	private Integer tahunAjaran;
	private String jurusan;
		
	public Kelas(String nama, Integer tahunAjaran, String jurusan){
		this.nama = nama;
		this.tahunAjaran = tahunAjaran;
		this.jurusan = jurusan;

		InnerClass inner = new InnerClass();
	}

	public String getNama(){ return this.nama; }

	public Integer getTahun() { return this.tahunAjaran; }

	public String getJurusan() { return this.jurusan; }
}
