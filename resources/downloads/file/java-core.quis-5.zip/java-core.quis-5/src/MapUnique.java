package data.list;

import java.util.*;

public class MapUnique{

	public static void main(String[] args){
		// 1
		Map<String, String> value = new HashMap<>();
		value.put("001", "laksdfj");
		value.put("002", "Dimas Maryanto");
		value.put("003", "laksdfj");
		value.put("006", "laksdfj");
		value.put("007", "laksdfj");
		value.put("008", "laksdfj");
		value.put("009", "laksdfj");
		value.put("010", "Karina Virgi");

		// 2
		value.forEach((k, v) ->{
			if(k.equals("010"))
				System.out.println(String.format("Nama saya %s, nipnya %s", v, k));
		});

		// 3
		Set<Integer> intValues = new HashSet<>(Arrays.asList(1,3,5,10,1,20,10,1,20,9,1));
		Object[] numbers = intValues.toArray();

		String text = String.format("Index ke 0 adalah %s, index ke 1 adalah %s, dan index ke 3 adalah %s",
			numbers[0], numbers[1], numbers[3]		
		);
		System.out.println(text);

		// 4		
		intValues.forEach((Integer i) -> { System.out.print(i + " "); });

		List<Integer> ganjilNumbers = new ArrayList<>();
		Iterator<Integer> itr = intValues.iterator();
		
		Integer i = 0;
		while(itr.hasNext()){
			Integer number = itr.next();
			if(i % 2 == 0){
				System.out.println(i);
				ganjilNumbers.add(number);
			}
			i++;
		}
		System.out.println();
		for(Integer baru: ganjilNumbers)
			System.out.print(baru+" ");
	}
}
