package data.list.model;

import java.util.List;
import java.util.ArrayList;
import java.time.LocalDate;


public class Mahasiswa{

	public Mahasiswa(String nim, String nama, LocalDate tanggal, Integer angkatan, Kelas kelas){
		this.nim = nim;
		this.nama = nama;
		this.tanggalLahir = tanggal;
		this.angkatan = angkatan;
		this.kelas = kelas;
	}

	private String nim, nama;
	private LocalDate tanggalLahir;
	private Integer angkatan;
	private Kelas kelas;


	public static void main(String[] args) {
		List<Mahasiswa> listMahasiswa = new ArrayList<>();
		Kelas si = new Kelas("SI", 2011, "Sistem Informasi");
		Kelas inf = new Kelas("IF" , 2011, "Teknik Informatika");

		listMahasiswa.add(
			new Mahasiswa(
				"1051148", 
				"Dimas Maryanto", 
				LocalDate.of(1992, 03, 11), 
				2014, 
				inf)
			);
		listMahasiswa.add(
			new Mahasiswa(
				"1051148", 
				"Dimas Maryanto", 
				LocalDate.now(), 
				2014, 
				inf)
			);
		listMahasiswa.add(
			new Mahasiswa(
				"1051148", 
				"Dimas Maryanto", 
				LocalDate.of(1992, 03, 11), 
				2014, 
				inf)
			);
		listMahasiswa.add(
			new Mahasiswa(
				"1051148", 
				"Dimas Maryanto", 
				LocalDate.of(1992, 03, 11), 
				2014, 
				inf)
			);


		for(Mahasiswa mhs : listMahasiswa){
			System.out.println(
					String.format("%s \t | %s \t | %s \t | %s \t | %s \t | %s \t ", 
						mhs.nim, 
						mhs.nama, 
						mhs.tanggalLahir, 
						mhs.angkatan, 
						mhs.kelas.getNama(), 
						mhs.kelas.getJurusan()
					));
		}
	}

}
