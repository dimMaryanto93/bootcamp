SELECT *
FROM employees
WHERE first_name LIKE 'A%';