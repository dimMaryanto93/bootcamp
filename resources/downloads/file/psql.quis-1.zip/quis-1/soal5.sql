SELECT *
FROM employees
WHERE last_name LIKE '_u%';