SELECT *
FROM employees
ORDER BY email DESC;