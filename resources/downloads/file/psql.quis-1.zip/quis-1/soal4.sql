SELECT *
FROM employees
WHERE employee_id IN (103, 115, 196, 187, 102, 100)