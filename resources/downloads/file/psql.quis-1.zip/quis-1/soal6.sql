SELECT DISTINCT (department_id)
FROM employees
ORDER BY department_id