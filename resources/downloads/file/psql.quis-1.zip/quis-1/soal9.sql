SELECT *
FROM employees
WHERE job_id NOT IN ('IT_PROG', 'SH_CLERK')