INSERT INTO karyawan_tdi (kode_karyawan, nama_lengkap, alamat_rumah, alamat_domisili, jabatan, bagian)
VALUES
  (2, 'Dimas Maryanto', 6232, 6230, 'IT_PROG', 60),
  (3, 'Hari Sapto Adi', 6233, 6233, 'IT_PROG', 60),
  (4, 'Deni Sutisna', 6220, 6220, 'IT_PROG', 60),
  (5, 'Arip Permana', 6233, 6233, 'AD_PRES', 90),
  (6, 'Zara', 6233, 6233, 'HR_REP', 10);