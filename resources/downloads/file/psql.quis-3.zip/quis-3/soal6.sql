SELECT
  karyawan.nama_lengkap                                AS nama,
  concat(rumah.street_address, ', ', rumah.city)       AS alamat_rumah,
  concat(domisili.street_address, ', ', domisili.city) AS alamat_domisili,
  divisi.department_name                               AS nama_divisi,
  tugas.job_title                                      AS sebagai
FROM karyawan_tdi karyawan
  JOIN departments divisi ON karyawan.bagian = divisi.department_id
  JOIN jobs tugas ON karyawan.jabatan = tugas.job_id
  JOIN locations rumah ON karyawan.alamat_rumah = rumah.location_id
  JOIN locations domisili ON karyawan.alamat_domisili = domisili.location_id