CREATE TABLE karyawan_tdi (
  kode_karyawan   SERIAL                NOT NULL PRIMARY KEY,
  nama_lengkap    CHARACTER VARYING(50) NOT NULL,
  alamat_rumah    INTEGER               NOT NULL REFERENCES locations (location_id),
  alamat_domisili INTEGER               NOT NULL REFERENCES locations (location_id),
  jabatan         CHARACTER VARYING(10) NOT NULL REFERENCES jobs (job_id),
  bagian          INTEGER               NOT NULL REFERENCES departments (department_id)
)