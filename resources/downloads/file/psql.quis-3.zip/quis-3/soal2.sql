INSERT INTO locations (location_id, street_address, postal_code, city, state_province, country_id)
VALUES (6232, 'Cinunuk', '40526', 'Kab. Bandung', 'Jawa Barat', 'ID'),
  (6231, 'Ujung Berung', '40521', 'Kota Bandung', 'Jawa Barat', 'ID'),
  (6233, 'Margahayu Raya', '40525', 'Kota Bandung', 'Jawa Barat', 'ID'),
  (6230, 'Blok M', '40620', 'Jakarta Selatan', 'DKI Jakarta', 'ID'),
  (6220, 'Slipi', '40521', 'Jakarta Utara', 'DKI Jakarta', 'ID');