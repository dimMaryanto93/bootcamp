package tdi.training.java.core.data;

public class LatihanNo3 {

	private String namaLengkap = "Dimas Maryanto";

	public String getNamaLengkap() {
		return namaLengkap;
	}
}
