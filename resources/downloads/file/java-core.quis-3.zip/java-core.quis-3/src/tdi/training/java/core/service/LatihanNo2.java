package tdi.training.java.core.service;

import tdi.training.java.core.data.LatihanNo3;

public class LatihanNo2{
	
	public void setNamaLengkap( LatihanNo3 lat) {
		System.out.println("Nama lengkap saya adalah " + lat.getNamaLengkap());	
	}
}
