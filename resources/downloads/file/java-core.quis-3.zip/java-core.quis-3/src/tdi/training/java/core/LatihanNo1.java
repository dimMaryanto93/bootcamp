package tdi.training.java.core;

import tdi.training.java.core.data.LatihanNo3;
import tdi.training.java.core.service.LatihanNo2;

public class LatihanNo1 {

	public static void main(String[] args){
		LatihanNo3 data = new LatihanNo3();
		LatihanNo2 service = new LatihanNo2();
		service.setNamaLengkap(data);
	}
}
