SELECT
  dep.department_id   AS dep_id,
  dep.department_name AS dep_name,
  sum(k.salary)       AS total_gaji
FROM employees k
  JOIN departments dep ON k.department_id = dep.department_id
GROUP BY dep_id, dep_name
ORDER BY total_gaji DESC;

-- select sum(salary) from employees where department_id = 80;

/**
Buatlah query, untuk menampilkan data total gaji seluruh karyawan dari setiap department kemudian urutkan berdasarkan gaji terbesar ke terkecil seperti berikut:

 dep_id |     dep_name     | total_gaji
--------+------------------+------------
     80 | Sales            |  304500.00
     50 | Shipping         |  156400.00
     90 | Executive        |   58000.00
    100 | Finance          |   51600.00
     60 | IT               |   28800.00
     30 | Purchasing       |   24900.00
    110 | Accounting       |   20300.00
     20 | Marketing        |   19000.00
     70 | Public Relations |   10000.00
     40 | Human Resources  |    6500.00
     10 | Administration   |    4400.00
(11 rows)

 */