SELECT
  k.employee_id                          AS kode_karyawan,
  concat(k.first_name, ' ', k.last_name) AS nama_lengkap,
  to_char(k.salary, '99,999,999')        AS gaji_karyawan,
  j.job_title                            AS jabatan,
  k.email                                AS email
FROM employees k
  JOIN jobs j ON k.job_id = j.job_id
WHERE k.salary >= (
  SELECT max(k2.salary)
  FROM employees k2
  WHERE k2.job_id = 'IT_PROG'
)
      AND commission_pct IS NOT NULL
ORDER BY gaji_karyawan, k.job_id

/**
Buatlah sebuah query untuk menampilkan semua data karyawan yang memiliki gaji lebih besar sama dengan nilai maximum setiap karyawan yang bekerja di department `IT_PROG` contohnya seperti berikut:
 */