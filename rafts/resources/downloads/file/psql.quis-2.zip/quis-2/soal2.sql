SELECT
  k.employee_id                          AS "Kode Karyawan",
  concat(k.last_name, ', ', k.first_name) AS nama_karyawan,
  initcap(d.department_name)             AS "Nama Bagian",
  CASE WHEN m.employee_id IS NULL
    THEN
      'Saya gak punya manager'
  ELSE concat(m.first_name, ' ', m.last_name)
  END                                    AS manager_name,
  upper(j.job_title)                     AS "Nama Jabatan"
FROM employees k
  JOIN departments d ON k.department_id = d.department_id
  LEFT OUTER JOIN employees m ON k.employee_id = m.manager_id
  JOIN jobs j ON k.job_id = j.job_id
ORDER BY manager_name, nama_karyawan;

/**
Buatlah query untuk menampilkan data, karyawan berserta nama managernya tetapi jika tidak punya manager tampilkan 'Saya Tidak punya manager' seperti berikut contohnya:

 Kode Karyawan |   nama_karyawan    |   Nama Bagian    |      manager_name      |          Nama Jabatan
---------------+--------------------+------------------+------------------------+---------------------------------
           100 | King, Steven       | Executive        | Adam Fripp             | PRESIDENT
           124 | Mourgos, Kevin     | Shipping         | Alana Walsh            | STOCK MANAGER
           100 | King, Steven       | Executive        | Alberto Errazuriz      | PRESIDENT
           102 | De Haan, Lex       | Executive        | Alexand'er Hunold      | ADMINISTRATION VICE PRESIDENT
           114 | Raphaely, Den      | Purchasing       | Alexander Khoo         | PURCHASING MANAGER
           121 | Fripp, Adam        | Shipping         | Alexis Bull            | STOCK MANAGER
           146 | Partners, Karen    | Sales            | Allan McEwen           | SALES MANAGER
           149 | Zlotkey, Eleni     | Sales            | Alyssa Hutton          | SALES MANAGER
           147 | Errazuriz, Alberto | Sales            | Amit Banda             | SALES MANAGER
           121 | Fripp, Adam        | Shipping         | Anthony Cabrio         | STOCK MANAGER
           123 | Vollman, Shanta    | Shipping         | Britney Everett        | STOCK MANAGER
           103 | Hunold, Alexand'er | It               | Bruce Ernst            | PROGRAMMER
           149 | Zlotkey, Eleni     | Sales            | Charles Johnson        | SALES MANAGER
           145 | Russell, John      | Sales            | Christopher Olsen      | SALES MANAGER
           147 | Errazuriz, Alberto | Sales            | Clara Vishney          | SALES MANAGER
           124 | Mourgos, Kevin     | Shipping         | Curtis Davies          | STOCK MANAGER
           108 | Greenberg, Nancy   | Finance          | Daniel Faviet          | FINANCE MANAGER
           147 | Errazuriz, Alberto | Sales            | Danielle Greene        | SALES MANAGER
           103 | Hunold, Alexand'er | It               | David Austin           | PROGRAMMER
           145 | Russell, John      | Sales            | David Bernstein        | SALES MANAGER
           147 | Errazuriz, Alberto | Sales            | David Lee              | SALES MANAGER

Ketentuannya:

1. `nama_karyawan`: gabungkan ke dua kolom `last_name` dan `fist_name`
2. `Nama Bagian`: diambil dari kolom `depertment_name` di tabel `departments`
3. `manager_name`: diambil dari kolom `first_name` dan `last_name` berdasarkan `manager_id` di tabel `employees`, jika tidak punya manager tampilkan 'Saya tidak punya manager'
4. `Nama Jabatan`: dimabil dari kolom `job_title` di tabel `jobs`
5. Diurutkan `manager_name` dan `nama_karyawan`
 */