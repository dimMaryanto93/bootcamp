SELECT
  empl.employee_id                                                                       AS "Kode Karyawan",
  dep.department_name                                                                    AS "Nama Department",
  concat(empl.first_name, ' ', empl.last_name)                                           AS "Nama Lengkap",
  to_char(empl.salary, '999,999,999')                                                    AS "Gaji sebulan",
  CASE WHEN empl.commission_pct IS NULL
    THEN 'Tidak punya komisi!'
  ELSE to_char((empl.salary * empl.commission_pct), '999,999,999')
  END                                                                                    AS "Mendapatkan Komisi",
  to_char(empl.salary + (empl.salary * coalesce(empl.commission_pct, 0)), '999,999,999') AS gaji_terima
FROM departments dep, employees empl
WHERE
  dep.department_id = empl.department_id AND
  empl.salary + (empl.salary * coalesce(empl.commission_pct, 0)) >= 12000
ORDER BY gaji_terima;

/**
buatlah _query_ untuk menampilkan data sebagai berikut:

 Kode Karyawan | Nama Department |   Nama Lengkap    | Gaji sebulan | Mendapatkan Komisi  | gaji_terima
---------------+-----------------+-------------------+--------------+---------------------+--------------
           205 | Accounting      | Shelley Higgins   |       12,000 | Tidak punya komisi! |       12,000
           169 | Sales           | Harrison Bloom    |       10,000 |        2,000        |       12,000
           108 | Finance         | Nancy Greenberg   |       12,000 | Tidak punya komisi! |       12,000
           158 | Sales           | Allan McEwen      |        9,000 |        3,150        |       12,150
           149 | Sales           | Eleni Zlotkey     |       10,500 |        2,100        |       12,600
           157 | Sales           | Patrick Sully     |        9,500 |        3,325        |       12,825
           150 | Sales           | Peter Tucker      |       10,000 |        3,000        |       13,000
           201 | Marketing       | Michael Hartstein |       13,000 | Tidak punya komisi! |       13,000
           162 | Sales           | Clara Vishney     |       10,500 |        2,625        |       13,125
           156 | Sales           | Janette King      |       10,000 |        3,500        |       13,500
           148 | Sales           | Gerald Cambrault  |       11,000 |        3,300        |       14,300
           174 | Sales           | Ellen Abel        |       11,000 |        3,300        |       14,300
           168 | Sales           | Lisa Ozer         |       11,500 |        2,875        |       14,375
           147 | Sales           | Alberto Errazuriz |       12,000 |        3,600        |       15,600
           102 | Executive       | Lex De Haan       |       17,000 | Tidak punya komisi! |       17,000
           101 | Executive       | Neena Kochhar     |       17,000 | Tidak punya komisi! |       17,000
           146 | Sales           | Karen Partners    |       13,500 |        4,050        |       17,550
           145 | Sales           | John Russell      |       14,000 |        5,600        |       19,600
           100 | Executive       | Steven King       |       24,000 | Tidak punya komisi! |       24,000
(19 rows)

Dengan ketentuan:
  1. `Nama Lengkap`: pengabungan antara `first_name` dan `last_name` dari tabel `employees`
  2. `Nama Department`: diambil dari table `departements`
  3. `Gaji sebulan`: diabil dari colomn `salary` dalam table `employees` yang diformat dipisahkan dengan `,` (koma)
  4. `Mendapatkan Komisi`: Jika column `commission_pct` bernilai `null` tampilkan `Tidak punya komisi` tetapi jika memiliki komisi maka tampilkan berapa komisi yang karyawan tersebut dapatkan berdaksarkan `salary`.
  5. `gaji_terima`: Gaji yang harus diterima oleh karyawan tersebut setelah ditambakan dengan komisi.
 */