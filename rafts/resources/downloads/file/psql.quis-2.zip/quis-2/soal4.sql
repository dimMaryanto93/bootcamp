SELECT
  (e.salary * 12)      AS gaji_setahun,
  count(e.employee_id) AS jumlah_karyawan
FROM employees e
WHERE e.commission_pct IS NOT NULL
GROUP BY gaji_setahun
ORDER BY gaji_setahun DESC;

/**
Buatlah query untuk menampilkan data, jumlah karyawan yang dikategorikan berdasarkan gaji setahun kemudian diurutkan berdasarkan kategori gaji tersebut dari terbesar hingga terkecil tetapi hanya yang memiliki komisi saja seperti berikut:

 gaji_setahun | jumlah_karyawan
--------------+-----------------
    168000.00 |               1
    162000.00 |               1
    144000.00 |               1
    138000.00 |               1
    132000.00 |               2
    126000.00 |               2
    120000.00 |               3
    115200.00 |               1
    114000.00 |               3
    108000.00 |               2
    105600.00 |               1
    103200.00 |               1
    100800.00 |               1
 */