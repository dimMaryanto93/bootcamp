package com.maryanto.dimas.logs.jdbc;

import com.maryanto.dimas.logs.jdbc.config.DatabaseProperties;
import com.maryanto.dimas.logs.jdbc.dao.NasabahDao;
import com.maryanto.dimas.logs.jdbc.dao.TabunganDao;
import com.maryanto.dimas.logs.jdbc.entity.Nasabah;
import com.maryanto.dimas.logs.jdbc.entity.Tabungan;
import com.maryanto.dimas.logs.jdbc.entity.TransaksiTabungan;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AplikasiTabungan {


    public static void main(String[] args) {
        Nasabah dimas = new Nasabah("Dimas Maryanto", "Jl.Bukit indah");
        Nasabah hilman = new Nasabah("Hilman Ramadhan", "Jl. Ujung berung");
        DataSource dataSource = DatabaseProperties.getDataSource();

        Connection connection = null;
        try {
            connection = DatabaseProperties.getDataSource().getConnection();
            connection.setAutoCommit(false);

            NasabahDao nasabahDao = new NasabahDao(connection);
            TabunganDao tabunganDao = new TabunganDao(connection);

            dimas = nasabahDao.save(dimas);
            Tabungan tabunganDimasUmroh = new Tabungan("Tabungan Umroh", dimas, BigDecimal.ZERO);
            Tabungan tabunganDimasHaji = new Tabungan("Tabungan Haji", dimas, BigDecimal.ZERO);
            hilman = nasabahDao.save(hilman);
            Tabungan tabunganHilmanUmroh = new Tabungan("Tabungan Umruh", hilman, BigDecimal.ZERO);

            tabunganDimasHaji = tabunganDao.save(tabunganDimasHaji);
            tabunganDimasUmroh = tabunganDao.save(tabunganDimasUmroh);
            tabunganHilmanUmroh = tabunganDao.save(tabunganHilmanUmroh);

            List<TransaksiTabungan> trxDimasUmroh = new ArrayList<>();
            List<TransaksiTabungan> trxDimasHaji = new ArrayList<>();
            List<TransaksiTabungan> trxHilmanUmroh = new ArrayList<>();

            trxDimasUmroh.add(
                    new TransaksiTabungan(
                            Date.valueOf("2017-03-21"),
                            new BigDecimal(500000),
                            BigDecimal.ZERO,
                            new BigDecimal(500000),
                            tabunganDimasUmroh
                    )
            );

            trxDimasUmroh.add(
                    new TransaksiTabungan(
                            Date.valueOf("2017-03-22"),
                            BigDecimal.ZERO,
                            new BigDecimal(250000),
                            new BigDecimal(250000),
                            tabunganDimasUmroh
                    )
            );
            tabunganDao.save(trxDimasUmroh);

            trxDimasHaji.add(
                    new TransaksiTabungan(
                            Date.valueOf("2017-03-23"),
                            new BigDecimal(200000),
                            BigDecimal.ZERO,
                            new BigDecimal(200000),
                            tabunganDimasHaji
                    )
            );
            trxDimasHaji.add(
                    new TransaksiTabungan(
                            Date.valueOf("2017-03-23"),
                            new BigDecimal(200000),
                            BigDecimal.ZERO,
                            new BigDecimal(400000),
                            tabunganDimasHaji
                    )
            );
            trxDimasHaji.add(
                    new TransaksiTabungan(
                            Date.valueOf("2017-03-23"),
                            new BigDecimal(400000),
                            BigDecimal.ZERO,
                            new BigDecimal(0),
                            tabunganDimasHaji
                    )
            );
            tabunganDao.save(trxDimasHaji);

            trxHilmanUmroh.add(
                    new TransaksiTabungan(
                            Date.valueOf("2017-03-23"),
                            new BigDecimal(500000),
                            BigDecimal.ZERO,
                            new BigDecimal(500000),
                            tabunganHilmanUmroh
                    )
            );
            tabunganDao.save(trxHilmanUmroh);
            connection.commit();

            List<TransaksiTabungan> semuaTransaksi = tabunganDao.findAllTransaksi();
            semuaTransaksi.forEach(trx -> System.out.println(trx.toString()));
            connection.close();
        } catch (SQLException sqle) {
            if (connection != null) {
                try {
                    connection.rollback();
                } catch (SQLException sqle2) {
                    sqle2.printStackTrace();
                }
            }
            sqle.printStackTrace();
        }

    }
}
