package com.maryanto.dimas.logs.jdbc.entity;

import java.math.BigDecimal;

public class Tabungan {

    public Tabungan (){}

    public Tabungan (String nama, Nasabah nasabah, BigDecimal saldo){
        this.namaTabungan = nama;
        this.nasabah = nasabah;
        this.saldo = saldo;
    }

    public Tabungan(Integer id, String nama, Nasabah nasabah, BigDecimal saldo){
        this.id = id;
        this.namaTabungan = nama;
        this.nasabah = nasabah;
        this.saldo = saldo;
    }
    
    private Integer id;
    private String namaTabungan;
    private Nasabah nasabah;
    private BigDecimal saldo;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNamaTabungan() {
        return namaTabungan;
    }

    public void setNamaTabungan(String namaTabungan) {
        this.namaTabungan = namaTabungan;
    }

    public Nasabah getNasabah() {
        return nasabah;
    }

    public void setNasabah(Nasabah nasabah) {
        this.nasabah = nasabah;
    }

    public BigDecimal getSaldo() {
        return saldo;
    }

    public void setSaldo(BigDecimal saldo) {
        this.saldo = saldo;
    }
}
