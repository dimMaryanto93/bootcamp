package com.maryanto.dimas.logs.jdbc.dao;

import com.maryanto.dimas.logs.jdbc.entity.Nasabah;

import java.sql.*;

public class NasabahDao {

    public NasabahDao(Connection dataSource){
        this.connection = dataSource;
    }

    private Connection connection;

    public Nasabah save(Nasabah nasabah) throws SQLException{
        //language=PostgreSQL
        String sql = "INSERT INTO \n" +
                "  mst_nasabah ( nama_nasabah, alamat) \n" +
                "VALUES (?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        preparedStatement.setString(1, nasabah.getNamaNasabah());
        preparedStatement.setString(2, nasabah.getNamaNasabah());
        preparedStatement.executeUpdate();
        ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
        nasabah.setId(0);
        if (generatedKeys.next())
            nasabah.setId(generatedKeys.getInt(1));
        generatedKeys.close();
        preparedStatement.close();
        return nasabah;
    }

}
