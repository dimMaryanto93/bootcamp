package com.maryanto.dimas.logs.jdbc.entity;

import java.math.BigDecimal;
import java.sql.Date;

public class TransaksiTabungan {

    public TransaksiTabungan() {
    }

    public TransaksiTabungan(
            Date tanggalTransaksi, BigDecimal debet, BigDecimal credit, BigDecimal saldo, Tabungan tabungan) {
        this.tanggalTransaksi = tanggalTransaksi;
        this.debet = debet;
        this.credit = credit;
        this.saldo = saldo;
        this.tabungan = tabungan;
    }

    private Integer id;
    private Date tanggalTransaksi;
    private BigDecimal debet;
    private BigDecimal credit;
    private BigDecimal saldo;
    private Tabungan tabungan;

    public Tabungan getTabungan() {
        return tabungan;
    }

    public void setTabungan(Tabungan tabungan) {
        this.tabungan = tabungan;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getTanggalTransaksi() {
        return tanggalTransaksi;
    }

    public void setTanggalTransaksi(Date tanggalTransaksi) {
        this.tanggalTransaksi = tanggalTransaksi;
    }

    public BigDecimal getDebet() {
        return debet;
    }

    public void setDebet(BigDecimal debet) {
        this.debet = debet;
    }

    public BigDecimal getCredit() {
        return credit;
    }

    public void setCredit(BigDecimal credit) {
        this.credit = credit;
    }

    public BigDecimal getSaldo() {
        return saldo;
    }

    public void setSaldo(BigDecimal saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return String.format("\"transaksi\" : {\n" +
                        "  \"id\": %s,\n" +
                        "  \"tanggal\": %s,\n" +
                        "  \"tabungan\": {\n" +
                        "    \"id\" : %s,\n" +
                        "    \"nama\": %s,\n" +
                        "    \"saldo\": %s,\n" +
                        "    \"nasabah\": {\n" +
                        "      \"id\" : %s,\n" +
                        "      \"nama\" : %s,\n" +
                        "      \"alamat\": %s  \n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"debet\" : %s,\n" +
                        "  \"kredit\" : %s,\n" +
                        "  \"saldo\" : %s\n" +
                        "}",
                id, tanggalTransaksi, tabungan.getId(), tabungan.getNamaTabungan(),
                tabungan.getSaldo(), tabungan.getNasabah().getId(), tabungan.getNasabah().getNamaNasabah(),
                tabungan.getNasabah().getAlamat(), debet, credit, saldo);
    }
}
