CREATE TABLE mst_nasabah (
  id           SERIAL PRIMARY KEY     NOT NULL,
  nama_nasabah CHARACTER VARYING(150) NOT NULL,
  alamat       TEXT
);

CREATE TABLE mst_tabungan (
  id            SERIAL PRIMARY KEY                  NOT NULL,
  nama_tabungan CHARACTER VARYING(50)               NOT NULL,
  nasabah_id    INTEGER REFERENCES mst_nasabah (id) NOT NULL,
  saldo         DECIMAL                             NOT NULL DEFAULT 0
);

CREATE TABLE trx_transaksi_tabungan (
  id                SERIAL PRIMARY KEY                   NOT NULL,
  tanggal_transaksi DATE                                 NOT NULL DEFAULT now(),
  tabungan_id       INTEGER REFERENCES mst_tabungan (id) NOT NULL,
  debet             DECIMAL                              NOT NULL DEFAULT 0,
  credit            DECIMAL                              NOT NULL DEFAULT 0,
  saldo             DECIMAL                              NOT NULL DEFAULT 0
);