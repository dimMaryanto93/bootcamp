package com.maryanto.dimas.logs.jdbc.config;

import org.apache.commons.dbcp2.BasicDataSource;

import javax.sql.DataSource;

public class DatabaseProperties {

    public static DataSource getDataSource() {
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setUrl("jdbc:postgresql://localhost:5432/hr");
        dataSource.setPassword("hr");
        dataSource.setUsername("hr");
        dataSource.setDriverClassName("org.postgresql.Driver");
        return dataSource;
    }

}
