package com.maryanto.dimas.logs.jdbc.entity;

public class Nasabah {

    public Nasabah(String nama, String alamat){
        this.namaNasabah = nama;
        this.alamat = alamat;
    }

    public Nasabah (Integer id, String nama, String alamat){
        this.id = id;
        this.namaNasabah = nama;
        this.alamat = alamat;
    }

    public Nasabah(){}

    private Integer id;
    private String namaNasabah;
    private String alamat;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNamaNasabah() {
        return namaNasabah;
    }

    public void setNamaNasabah(String namaNasabah) {
        this.namaNasabah = namaNasabah;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }
}
