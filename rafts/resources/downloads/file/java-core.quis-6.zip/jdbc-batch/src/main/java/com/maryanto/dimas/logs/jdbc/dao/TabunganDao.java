package com.maryanto.dimas.logs.jdbc.dao;

import com.maryanto.dimas.logs.jdbc.entity.Nasabah;
import com.maryanto.dimas.logs.jdbc.entity.Tabungan;
import com.maryanto.dimas.logs.jdbc.entity.TransaksiTabungan;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TabunganDao {

    private final Connection connection;

    public TabunganDao(Connection connection) {
        this.connection = connection;
    }

    public Tabungan save(Tabungan tabungan) throws SQLException {
        //language=PostgreSQL
        String sql = "INSERT INTO \n" +
                "  mst_tabungan( nama_tabungan, nasabah_id, saldo) \n" +
                "VALUES (?, ?, ?)";

        PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        preparedStatement.setString(1, tabungan.getNamaTabungan());
        preparedStatement.setInt(2, tabungan.getNasabah().getId());
        preparedStatement.setBigDecimal(3, tabungan.getSaldo());
        preparedStatement.executeUpdate();

        ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
        tabungan.setId(0);
        if (generatedKeys.next())
            tabungan.setId(generatedKeys.getInt(1));
        preparedStatement.close();
        generatedKeys.close();
        return tabungan;
    }

    public void save(List<TransaksiTabungan> listTransaksi) throws SQLException {
        //language=PostgreSQL
        String sql = "INSERT INTO\n" +
                "  trx_transaksi_tabungan (tanggal_transaksi, tabungan_id, debet, credit, saldo)\n" +
                "VALUES (?, ?, ? ,?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        for (TransaksiTabungan trx : listTransaksi) {
            preparedStatement.setDate(1, trx.getTanggalTransaksi());
            preparedStatement.setInt(2, trx.getTabungan().getId());
            preparedStatement.setBigDecimal(3, trx.getDebet());
            preparedStatement.setBigDecimal(4, trx.getCredit());
            preparedStatement.setBigDecimal(5, trx.getSaldo());
            preparedStatement.addBatch();
        }
        preparedStatement.executeBatch();
        preparedStatement.clearBatch();
        preparedStatement.close();
    }

    public List<TransaksiTabungan> findAllTransaksi() throws SQLException {
        List<TransaksiTabungan> listTransaksi = new ArrayList<>();
        String sql = "SELECT trx.id AS transaksi_id,\n" +
                "  n.id AS id_nasabah,\n" +
                "  n.nama_nasabah AS nama_nasabah,\n" +
                "  n.alamat AS alamat_nasabah,\n" +
                "  tab.id AS id_tabungan,\n" +
                "  tab.nama_tabungan AS nama_tabungan,\n" +
                "  trx.debet AS debet,\n" +
                "  trx.credit AS kredit,\n" +
                "  trx.saldo AS saldo\n" +
                "FROM trx_transaksi_tabungan trx\n" +
                "  JOIN mst_tabungan tab ON trx.tabungan_id = tab.id\n" +
                "  JOIN mst_nasabah n ON tab.nasabah_id = n.id";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            TransaksiTabungan trx = new TransaksiTabungan();
            trx.setId(resultSet.getInt("transaksi_id"));
            trx.setDebet(resultSet.getBigDecimal("debet"));
            trx.setCredit(resultSet.getBigDecimal("kredit"));
            trx.setSaldo(resultSet.getBigDecimal("saldo"));
            trx.setTabungan(new Tabungan(
                    resultSet.getInt("id_tabungan"),
                    resultSet.getString("nama_tabungan"),
                    new Nasabah(
                            resultSet.getInt("id_nasabah"),
                            resultSet.getString("nama_nasabah"),
                            resultSet.getString("alamat_nasabah")
                    ),
                    BigDecimal.ZERO
            ));
            listTransaksi.add(trx);
        }
        resultSet.close();
        preparedStatement.close();
        return listTransaksi;
    }
}
