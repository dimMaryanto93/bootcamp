package tdi.training.java.core;

import tdi.training.java.core.model.nasabah.NasabahPerorangan;

public class MainApplication{
	public static void main(String[] ags){
		NasabahPerorangan dimas = new NasabahPerorangan("62213424", "Dimas Maryanto", "Jl.Bukit indah no B8", "0821173");
		System.out.println(dimas.toString());
	}
}
