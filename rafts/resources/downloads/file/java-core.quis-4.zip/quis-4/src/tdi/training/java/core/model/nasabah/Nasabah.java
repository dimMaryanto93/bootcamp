package tdi.training.java.core.model.nasabah;

import java.math.BigDecimal;

public class Nasabah {

	private String noIdentitas;
	private boolean active;
	private BigDecimal saldo;

	public String getNomorIdentitas(){
		return this.noIdentitas;
	}

	public void setNomorIdentitas(String x){
		this.noIdentitas = x;
	}

	public boolean isActive(){
		return this.active;
	}

	public void setActive(boolean x){
		this.active = x;
	}

	public BigDecimal getSaldo(){
		return this.saldo;
	}	

	public void setSaldo(BigDecimal y){
		this.saldo = y;
	}
}
