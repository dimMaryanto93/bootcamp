package com.maryanto.dimas.tdi.training.java.core;

import java.lang.Math;

public class Latihan4 {

	public static void main(String[] ags){
		for(int i = 0; i <= 10 ; i++){
			for(int j = 0; j < 5; j++){
				if(i % 2 == 0)	System.out.print((i*j) + " ");
				else System.out.print(Math.pow(i, j)+" ");
			}
			System.out.println();
		}	
	}
}
